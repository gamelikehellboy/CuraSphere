// src/components/DoctorCard.js
import React from 'react';
import './DoctorCardStyle.css'; // Importing CSS file

const DoctorCard = ({ name, degree, specialty, rating, available, image }) => {
  return (
    <div className="doctor-card">
      <div className="doctor-info">
        <h3 className="doctor-name">{name}</h3>
        <p className="doctor-details">{degree}, {specialty}</p>
        <p className="doctor-availability">Rating: {rating} {available ? ', Available' : ', Not Available'}</p>
      </div>
      <div className="doctor-image">
        {image ? (
          <img src={image} alt={name} />
        ) : (
          <div className="image-placeholder">No Image</div>
        )}
      </div>
    </div>
  );
};

export default DoctorCard;
